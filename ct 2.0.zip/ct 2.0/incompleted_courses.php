<?php

// file that includes all data base propeties for connection
include("database.php");

// // logo
// echo "<link rel='shortcut icon' href='logo.jpeg' type='image/x-icon'>";

// css file
echo "<link rel='stylesheet' type='text/css' href='query_results.css'/>";

session_start();  //starts session

$victim_id = $_SESSION['victim_id'];
$victim_batch = $_SESSION['victim_batch'];

// Query to get remaining mandatory courses
$query = "SELECT t1.course_code as course_code,
                 t1.course_name as course_name,
                 t1.prerequisites as prerequisites
          FROM (SELECT `Course Code` as course_code, 
                       `Course Name` as course_name,
                       `Prerequisites` as prerequisites
                FROM `$victim_batch`
                WHERE `Course Type` = 'M')t1 LEFT JOIN 
               (SELECT `course_code` as course_code 
                FROM victims_course_data 
                WHERE victim_id = '$victim_id' and course_type = 'M')t2 
          ON t1.course_code = t2.course_code
          WHERE t2.course_code is NULL";

$result = $conn->query($query); // execute query

echo "<html>";
echo "<h2>Incompleted Mandatory Courses</h2>";

if($result->num_rows > 0){
  // printing each record in php file
  echo "<table> 
       <tr>
         <th>S_no </th>
         <th> Course_Code </th>
         <th> Course_Name </th>
         <th> Prerequisites</th>
       </tr>";
  $s_no = 1;
  while($row = $result->fetch_assoc())
  {
      $row1 = $row['course_code'];
      $row2 = $row['course_name'];
      $row3 = $row['prerequisites'];
      echo"<tr>
           <td>" .$s_no. ".</td>".
           "<td>" .$row1. "</td>".
           "<td>" .$row2. "</td>".
           "<td>" .$row3. "</td>".
          "</tr>";
  
      $s_no++;
  }
  echo "</table>";
}
else{
  echo "<div style = 'box-shadow: 0 0 20px 0 rgba(120, 120, 110,0.89);
                      padding: 1rem;
                      width: max-content;
                      background-color: #706e6e;'>
          <p>0 results found.</p>
          <p>What! You completed all Mandatory Courses!.. Congrats!...</p>
        </div></html>";
}

// query to get all elective courses
$query = "SELECT `Course Code` FROM `$victim_batch`
          WHERE `Course Type` = 'E'";

$result = $conn->query($query);

$total_elective = $result->num_rows;

 // Query Elective Courses...
$query = "SELECT t1.course_code as course_code,
                 t1.course_name as course_name,
                 t1.prerequisites as prerequisites
          FROM (SELECT `Course Code` as course_code, 
                       `Course Name` as course_name,
                       `Prerequisites` as prerequisites
                FROM `$victim_batch`
                WHERE `Course Type` = 'E')t1 LEFT JOIN 
               (SELECT `course_code` as course_code 
                FROM victims_course_data 
                WHERE victim_id = '$victim_id' and course_type = 'E')t2 
          ON t1.course_code = t2.course_code
          WHERE t2.course_code is NULL";

$result = $conn->query($query); // executes query

$remaining_electives = $result->num_rows + 6 - $total_elective;;
$val = $result->num_rows;

echo "<html>";

// tell student how many he needs more
 if($remaining_electives > 0) // he needs few more
     echo "<h2>Incompleted Elective Courses<br>Choose $remaining_electives out of $val</h2>";
 else if($remaining_electives == 0)
     echo "<h2>Hey!..you completed all Electives...</h2>";
 else
     echo "<h2>Hey!..you did more than required i.e.,.8</h2>";

if($result->num_rows > 0){
    // printing each record in php file
    echo "<table> 
         <tr>
           <th>S_no </th>
           <th> Course_Code </th>
           <th> Course_Name </th>
           <th> Prerequisites</th>
         </tr>";
    $s_no = 1;
    while($row = $result->fetch_assoc())
    {
        $row1 = $row['course_code'];
        $row2 = $row['course_name'];
        $row3 = $row['prerequisites'];
        echo"<tr>
             <td>" .$s_no. ".</td>".
             "<td>" .$row1. "</td>".
             "<td>" .$row2. "</td>".
             "<td>" .$row3. "</td>".
            "</tr>";
    
        $s_no++;
    }
    echo "</table>";
}      

// it never happens, bcz student no need to complete all the courses
else{
  echo "<div style = 'box-shadow: 0 0 20px 0 rgba(120, 120, 110,0.89);
                      padding: 1rem;
                      width: max-content;
                      background-color: #706e6e;'>
          <p>0 results found.</p>
          <p>What! You completed all elective courses!.. Congrats!...</p>
       </div> </html>";
} 

// Query for incompleted open elective courses

// query to get all open elective courses
$query = "SELECT `Course Code` FROM `$victim_batch`
          WHERE `Course Type` = 'OE'";

$result = $conn->query($query);

$total_elective = $result->num_rows;

 // Query Elective Courses...
$query = "SELECT t1.course_code as course_code,
                 t1.course_name as course_name,
                 t1.prerequisites as prerequisites
          FROM (SELECT `Course Code` as course_code, 
                       `Course Name` as course_name,
                       `Prerequisites` as prerequisites
                FROM `$victim_batch`
                WHERE `Course Type` = 'OE')t1 LEFT JOIN 
               (SELECT `course_code` as course_code 
                FROM victims_course_data 
                WHERE victim_id = '$victim_id' and course_type = 'OE')t2 
          ON t1.course_code = t2.course_code
          WHERE t2.course_code is NULL";

$result = $conn->query($query); // executes query

$remaining_electives = $result->num_rows + 2 - $total_elective;;
$val = $result->num_rows;

echo "<html>";

// tell student how many he needs more
 if($remaining_electives > 0) // he needs few more
     echo "<h2>Incompleted Open Elective Courses<br>Choose $remaining_electives out of $val</h2>";
 else if($remaining_electives == 0)
     echo "<h2>Hey!..you completed all Open Electives...</h2>";
 else
     echo "<h2>Hey!..you did more than required i.e.,.8</h2>";

if($result->num_rows > 0){
    // printing each record in php file
    echo "<table> 
         <tr>
           <th>S_no </th>
           <th> Course_Code </th>
           <th> Course_Name </th>
           <th> Prerequisites</th>
         </tr>";
    $s_no = 1;
    while($row = $result->fetch_assoc())
    {
        $row1 = $row['course_code'];
        $row2 = $row['course_name'];
        $row3 = $row['prerequisites'];
        echo"<tr>
             <td>" .$s_no. ".</td>".
             "<td>" .$row1. "</td>".
             "<td>" .$row2. "</td>".
             "<td>" .$row3. "</td>".
            "</tr>";
    
        $s_no++;
    }
    echo "</table>";
}      

// it never happens, bcz student no need to complete all the courses
else{
  echo "<div style = 'box-shadow: 0 0 20px 0 rgba(120, 120, 110,0.89);
                      padding: 1rem;
                      width: max-content;
                      background-color: #706e6e;'>
          <p>0 results found.</p>
          <p>What! You completed all open elective courses!.. Congrats!...</p>
       </div> </html>";
} 

?>