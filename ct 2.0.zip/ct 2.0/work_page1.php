<?php

// file that includes all data base properties for connection
include("database.php");

// css file
echo "<link rel='stylesheet' type='text/css' href='query_results.css'/>";

session_start();  //starts session

$victim_id = $_SESSION['victim_id']; // PK - 1 to get student record from data table
$victim_regno = $_SESSION['victim_regno'];  // PK to get student record from data table
$victim_batch = $_SESSION['victim_batch'];
$_SESSION['course_type'] = 'M';

// Query Mandatory Courses....
$query = "SELECT t1.course_code as course_code,
                 t1.course_name as course_name
          FROM (SELECT `Course Code` as course_code, `Course Name` as course_name
                FROM `$victim_batch`
                WHERE `Course Type` = 'M')t1 LEFT JOIN 
               (SELECT `course_code` as course_code 
                FROM victims_course_data 
                WHERE victim_id = '$victim_id' AND course_type = 'M')t2 ON t1.course_code = t2.course_code
          WHERE t2.course_code is NULL";

$result = $conn->query($query); // it get all query results....
 
echo "<html>";
echo "<h2>Choose and upload your Mandatory Courses</h2>";

if($result->num_rows > 0){

  // printing each record in php file
  echo "<form action='victim_course_data.php' method='post'> <table> 
        <tr>
         <th>S.no </th>
         <th> CourseCode </th>
         <th> CourseName </th>
         <th> S <th>
         <th> A <th>
         <th> B <th>
         <th> C <th>
         <th> D <th>
         <th> E <th>
         <th> F <th>
       </tr>";

  $s_no = 1;

  while($row = $result->fetch_assoc())
  {
      $row1 = $row['course_code'];
      $row2 = $row['course_name'];
      echo"<tr>
           <td>" .$s_no. ".</td>".
           "<td>" .$row1. "</td>".
           "<td>" .$row2. "</td>".
           "<td><input type='radio' name=$row1 value='S'></td>".
           "<td><input type='radio' name=$row1 value='A'></td>".
           "<td><input type='radio' name=$row1 value='B'></td>".
           "<td><input type='radio' name=$row1 value='C'></td>".
           "<td><input type='radio' name=$row1 value='D'></td>".
           "<td><input type='radio' name=$row1 value='E'></td>".
           "<td><input type='radio' name=$row1 value='F'></td>
           </tr>";
      $s_no++;
  }

  echo "</table>
        <input type='submit' value='Upload' id='upload-btn' style='padding: .1rem 2rem;
                                                                   color: black;
                                                                   border-radius: 2px;
                                                                   margin: 1.5rem;
                                                                   margin-left: 40%;
                                                                   background-color: #9fa8a9;
                                                                   height: auto;
                                                                   font-size: 1.25rem;'>
        </form>";

}

else{
  echo "<div style = 'box-shadow: 0 0 20px 0 rgba(120, 120, 110,0.89);
                      padding: 1rem;
                      width: max-content;
                      background-color: #706e6e;'>
          <p>0 results found.</p>
          <p>What? you completed all Mandatory Courses!.. congrats!...</p>
        </div>";
}

echo "</html>";

?>