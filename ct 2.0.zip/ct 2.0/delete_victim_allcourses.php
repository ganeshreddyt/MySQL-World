<?php

 // file that includes all data base propeties for connection
 include("database.php");

// to get session variables..
session_start();

// get session variables 
$victim_id = $_SESSION['victim_id'];
$victim_batch = $_SESSION['victim_batch'];

$query = "DELETE FROM victims_course_data WHERE victim_id = '$victim_id'";

$result = $conn->query($query); // process the query 

$query = "SELECT * FROM victims_course_data WHERE victim_id = '$victim_id'";

$result = $conn->query($query); // to get query results(safety check)

if($result->num_rows == 0){
    echo "<script>
          alert('Your course data Deleted!..'); 
          location.href = history.back(); </script>";
}
else{
    echo "<script>
    alert('Deletion process Interupted!..try again!..'); 
    location.href =  history.back(); </script>";
}

?>
