<?php
   
   // file that includes all data base propeties for connection
   include("database.php");

  // get details from form
  $victim_regno = $_POST["victim-regno"];
  $victim_gender = $_POST["victim-gender"];
  $victim_id = $_POST["victim-id"];
  $victim_pwd = $_POST["victim-password"];
  $victim_batch = $_POST["victim-batch"];
  $pwd_hint = $_POST["password-hint"];

  // query to find out any such user presence
  $query = "SELECT * 
            FROM victims_data 
            WHERE victim_regno = '$victim_regno' AND
            victim_id  = '$victim_id'";

  $response =  $conn->query($query); // execute query
  
  // to get curr date and time
  date_default_timezone_set('Asia/Kolkata');
  $date_of_register = date('Y-m-d h:i:s', time());
   

  // if no such user found with same details
  if($response->num_rows == 0){
     $query = "INSERT INTO victims_data(
               victim_regno, victim_gender, victim_id, 
               victim_pwd, victim_batch, password_hint, date_of_register) 
               VALUES('$victim_regno', '$victim_gender', '$victim_id', 
                      '$victim_pwd', '$victim_batch', '$pwd_hint', '$date_of_register') ";

    // send query to the database to add values and confirm if successful
    $result = $conn->query($query);

    // for confirmation
    $query = "SELECT victim_id 
              FROM victims_data
              WHERE victim_id = '$victim_id'";
   
    $result = $conn->query($query);  // process the query

    // registration success
   if($result->num_rows > 0){
      echo "<script>    
            alert('Registration success!...');
            location.href = 'index.html';
            </script>";
   } 
   else{
      echo "<script>    
            alert('Hey sorry!..Something going bad pray for GOD!..or try again!..');
            location.href = 'register.html';
            </script>";
   }      
   }

 // else already exists
 else{
  echo "<script>
        alert('Dont cheat Reg.no OR Identity already exists, try new!..');
        location.href = 'register.html';
        </script>";
 }

?>

 

