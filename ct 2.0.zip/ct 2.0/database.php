<?php

// database details..
$host = 'localhost';
$user_name = 'root';
$pass = '';
$db_name = 'victims_db';

// establish connection
$conn = new mysqli($host, $user_name, $pass, $db_name);

// if connection is not success
if(!$conn){  
    die("Something going to be disaster!..Pray for GOD".mysqli_connect_error());
    exit();
}
 
?>