<?php

// file that includes all data base propeties for connection
include("database.php");

// to get session variables..
session_start();

// get session variables 
$victim_id = $_SESSION['victim_id'];

// get data from the form
$new_victim_id = $_POST['new-victim-id'];
$new_victim_pwd = $_POST['new-victim-pwd'];
$password_hint = $_POST['new-pwd-hint'];

$query = "UPDATE victims_data 
          SET victim_id = '$new_victim_id', victim_pwd = '$new_victim_pwd', password_hint = '$password_hint'
          WHERE victim_id = '$victim_id'";

$result = $conn->query($query); // process the query (I think updated)

// lets confirm
$query = "SELECT victim_id, victim_pwd 
          FROM victims_data
          WHERE victim_id = '$new_victim_id'";

$result = $conn->query($query);  // process query
$obj = $result->fetch_assoc();  // to get data from the query
          
// after confirmation
  echo "<script>
         alert('Your changes applied succesfully man!...Atleast this time don't tell to anyone!...'); 
         location.href = 'project.html'; </script>";

?>
