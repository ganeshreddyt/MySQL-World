<?php

// file that includes all data base propeties for connection
include("database.php");

// to get session variables..
session_start();

// get session variables 
$victim_id = $_SESSION['victim_id'];
$victim_regno = $_SESSION['victim_regno'];

// get data from the form
$victim_feedback = $_POST['victim-feedback'];

$query = "INSERT INTO victims_feedback(victim_regno, victim_feedback) 
          VALUES('$victim_regno', '$victim_feedback')";

$result = $conn->query($query); // process the query (I think updated)
        
// after confirmation
  echo "<script>
         alert('Thank you for your feedback!...'); 
         location.href = history.back(); </script>";

?>
