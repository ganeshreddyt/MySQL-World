<?php

 // file that includes all data base propeties for connection
 require("database.php");

session_start();  // creats global variables..


// get data from log-in form
$victim_id = $_POST['victim-id'];
$victim_pwd = $_POST['victim-password'];
$action_to_be_done = $_POST['action'];

// if victim hit login btn...
if($action_to_be_done == 'login'){

// query to fetch for the valid matched credentials
$query = "select * from victims_data where victim_id  = '$victim_id' and victim_pwd = '$victim_pwd'";

$response =  $conn->query($query); // execute query

   // if victim exists 
   if($response->num_rows > 0){
    
      // creats session variable
      $obj = $response->fetch_assoc();
      $_SESSION['victim_id'] = $victim_id;
      $_SESSION['victim_gender'] = $obj['victim_gender'];
      $_SESSION['victim_regno'] = $obj['victim_regno'];
      $_SESSION['victim_batch'] = $obj['victim_batch'];
      
     // navigate to project file to provide all desired services to the user(student)
     header("Location: project.html");
   }
   
   // if not exists
   else{
      echo "<script>
           alert('Again forgotted ahh!...Ushh...');
           location.href = 'index.html';
           </script>";
       }

}

// if victim hit hint btn..  (else if is for confirmation..almost 99.99999% it be hint only, but for confirmation)
else if($action_to_be_done == 'hint'){

// query to get hint of victim he forgot his password
$query = "SELECT password_hint AS hint 
          FROM victims_data 
          WHERE victim_id = '$victim_id'";

$response = $conn->query($query); // execute query

    if($response->num_rows > 0){  
        $obj = $response->fetch_assoc();
        $hint= $obj['hint'];

        echo "<script>
              location.href = 'index.html';
              alert('Here is your hint!... --> $hint');
              </script>";
    }

    // if not
    else{
        echo "<script>
             alert('Again cheating!..ID itself incorrect!..');
             location.href = 'index.html';
             </script>";
    }

}

// for safe side(it won't happen at any cast but for safety)
else{

    echo "Something going to be disaster, pray for GOD!...";
    echo "Close application and try with valid details.";

}

?>

