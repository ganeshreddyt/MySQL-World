<?php

 // file that includes all data base propeties for connection
 include("database.php");

// to get session variables..
session_start();

// get session variables 
$victim_id = $_SESSION['victim_id'];
$victim_batch = $_SESSION['victim_batch'];

// get data from the form
$course_code = $_POST['course-code'];

$query = "SELECT * FROM victims_course_data WHERE victim_id = '$victim_id' AND course_code = '$course_code'";

$result = $conn->query($query); // process the query 

// if no such valid record found means he didn't study it yet
if($result->num_rows == 0){
    echo "<script>
          alert('Hey lier!..You didnt study that yet!..'); 
          location.href = 'project.html'; </script>";
}
else{
    
    $query = "DELETE FROM victims_course_data WHERE victim_id = '$victim_id' AND course_code = '$course_code'";
    
    $result = $conn->query($query); // to get query results(safety check)
    
    // for safety check
    if($result->num_rows > 0){
        echo "<script>
              alert('Hey sorry!..Try course code entering like UBA XX'); 
              location.href = 'project.html'; </script>";
    }
    else{
        echo "<script>
              alert('One of your course data has been deleted!...'); 
              location.href = 'project.html'; </script>";
    }
}

?>
