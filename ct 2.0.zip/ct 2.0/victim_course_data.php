<?php

session_start(); // start session
include("database.php"); // include database

// get victim id, regno from session
$victim_regno = $_SESSION['victim_regno'];
$victim_id = $_SESSION['victim_id'];
$victim_batch = $_SESSION['victim_batch'];
$course_type = $_SESSION['course_type'];


// if student wants mandatory course related
if($course_type == 'M'){

        // query to get all mandatory courses of student batch
        $query = "SELECT `Course Code` AS  course_code FROM `$victim_batch` WHERE `Course Type` = 'M'";
        $response = $conn->query($query); // execute query
        $courses  = [];
        
        // push all the courses into an array
        while($row = $response->fetch_assoc()) 
        {
          $courses[] = $row["course_code"];
        }
         
        //insert the values into victims_course_data one by one
        for($i = 0; $i < count($courses); $i++)
        {
            $val = $_POST[$courses[$i]];  // data from courses
            
            if(isset($val))
            {
             // insert command to insert the data into table
             $query = "insert into victims_course_data(victim_id, course_code, course_grade, course_type) values('$victim_id', '$courses[$i]', '$val', 'M')";
             $response =  $conn->query($query);  // execute query
            }
        }
        
        echo "<script>
              alert('Uploaded Done!..');
              location.href = history.back();
              </script>";
    }


    // if user wants to upload elective or open elective courses
else if($course_type == 'E'){

        // query to get all mandatory courses of student batch
        $query = "SELECT `Course Code` AS  course_code FROM `$victim_batch` WHERE `Course Type` = 'E'";
        $response = $conn->query($query); // execute query
        $courses  = [];
        
        // push all the courses into an array
        while($row = $response->fetch_assoc()) 
        {
          $courses[] = $row["course_code"];
        }
         
        //insert the values into victims_course_data one by one
        for($i = 0; $i < count($courses); $i++)
        {
            $val = $_POST[$courses[$i]];  // data from courses
            
            if(isset($val))
            {
             // insert command to insert the data into table
             $query = "insert into victims_course_data(victim_id, course_code, course_grade, course_type) values('$victim_id', '$courses[$i]', '$val', 'E')";
             $response =  $conn->query($query);  // execute query
            }
        }

        // query to get all mandatory courses of student batch
        $query = "SELECT `Course Code` AS  course_code FROM `$victim_batch` WHERE `Course Type` = 'OE'";
        $response = $conn->query($query); // execute query
        $courses  = [];
        
        // push all the courses into an array
        while($row = $response->fetch_assoc()) 
        {
          $courses[] = $row["course_code"];
        }
         
        //insert the values into victims_course_data one by one
        for($i = 0; $i < count($courses); $i++)
        {
            $val = $_POST[$courses[$i]];  // data from courses
            
            if(isset($val))
            {
             // insert command to insert the data into table
             $query = "insert into victims_course_data(victim_id, course_code, course_grade, course_type) values('$victim_id', '$courses[$i]', '$val', 'OE')";
             $response =  $conn->query($query);  // execute query
            }
        }
        
         echo "<script>
               alert('Uploaded Done!..');
               location.href = history.back();
               </script>";

}

    //for safe side
    else{

        //it won't happen but for safety
        echo "<script>
              alert('Something going bad!..Pray for GOD!...');
              location.href = history.back();
              </script>";
    }

     ?>
