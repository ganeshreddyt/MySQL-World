<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.slim.min.js"></script>
    <title>Course Tracker</title>
</head>
<body>

<!-- php code to sweetalert the user cgpa --->

<?php

 // file that includes all data base propeties for connection
 include("database.php");

session_start();  //starts session

$victim_id = $_SESSION['victim_id'];
$victim_batch = $_SESSION['victim_batch'];

$query = " with victim_data(course_grade) as 
              (select course_grade from victims_course_data where victim_id = '$victim_id' and course_grade <> 'F'),
           total_score(total) as 
              (select sum(CASE
                            when course_grade = 'S' then 10
                            when course_grade = 'A' then 9
                            when course_grade = 'B' then 8
                            when course_grade = 'C' then 7
                            when course_grade = 'D' then 6
                            else 5
                         end) from victim_data)
      select total_score.total / count(victim_data.course_grade) as cgpa from victim_data, total_score";

$result = $conn->query($query); // to get query results..
$cgpa = 0;

$cgpa_obj = $result->fetch_assoc();

$cgpa = $cgpa_obj['cgpa'];

// if he was not yet studied one course atleast
if(empty($cgpa)){
   echo "<script>
         swal({
            title: 'Your CGPA is 0.0',
            text: 'Not Choose any Course yet!..',
            }).then(function() {
            history.back();
            });
          </script>";
}

else if($cgpa < 7.00){
   echo "<script>
         swal({
            title: 'Your CGPA is $cgpa',
            text: 'Good effort!..Need improvement..',
            type: 'danger'
            }).then(function() {
            history.back();
            });
         </script>";
}

// if he maintain good cgpa..
else if($cgpa >= 7.00){
   echo "<script>
         swal({
            title: 'Your CGPA is $cgpa',
            text: 'Keep it up!..',
            type: 'success'
            }).then(function() {
            history.back();
            });
        </script>";
}

//else on worst server crashing
else{
   echo "Error occured to fectch CGPA.";
   echo "Try Again.";
}
?>

</body>
</html>
