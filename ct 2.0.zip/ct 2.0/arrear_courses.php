
<?php
 
 // file that includes all data base propeties for connection
 include("database.php");
 
// logo
echo "<link rel='shortcut icon' href='logo.jpeg' type='image/x-icon'>";

// css file
echo "<link rel='stylesheet' type='text/css' href='query_results.css'/>";

session_start();  //starts session

$victim_id = $_SESSION['victim_id'];
$victim_batch = $_SESSION['victim_batch'];

// Query arrear mandatory courses
$query="SELECT t1.course_code as course_code,
               t2.course_name as course_name,
               t2.prerequisites as prerequisites,
               t1.course_grade as course_grade,
               CASE WHEN t2.course_type = 'M' THEN 'Mandatory'
                    WHEN t2.course_type = 'E' THEN 'Elective'
                    ELSE 'Open Elective'
               END as course_type
        FROM (SELECT course_code, course_grade 
              FROM victims_course_data
              WHERE victim_id = '$victim_id' and course_grade = 'F')t1 JOIN
             (SELECT `Course Code` as course_code,
                     `Course Name` as course_name,
                     `Prerequisites` as prerequisites,
                     `Course Type` as course_type
              FROM `$victim_batch`)t2 on t1.course_code = t2.course_code
        ORDER BY 5";
 

$result = $conn->query($query); // executes query

echo "<html>";
echo "<h2>Arrear Courses you have</h2>";

if($result->num_rows > 0){
    // printing each record in php file
    echo "<table> 
         <tr>
           <th>S.no </th>
           <th> Course Code </th>
           <th> Course Name </th>
           <th> Prerequisite</th>
           <th> Course Grade</th>
           <th> Course Type </th>
         </tr>";
    $s_no = 1;
    while($row = $result->fetch_assoc())
    {
        $row1 = $row['course_code'];
        $row2 = $row['course_name'];
        $row3 = $row['prerequisites'];
        $row4 = 'F';
        $row5 = $row['course_type'];

    if($row3 == 'F'){
        echo "<tr style = 'color: red'>
        <td>" .$s_no. ".</td>".
        "<td>" .$row1. "</td>".
        "<td>" .$row2. "</td>".
        "<td>" .$row3. "</td>".
        "<td>" .$row4. "</td>".
        "<td>" .$row5. "</td>".
      "</tr>";
    }
    else{
    echo"<tr>
        <td>" .$s_no. ".</td>".
        "<td>" .$row1. "</td>".
        "<td>" .$row2. "</td>".
        "<td>" .$row3. "</td>".
        "<td>" .$row4. "</td>".
        "<td>" .$row5. "</td>".
        "</tr>";
    }
        $s_no++;
    }
    echo "</table>";
    echo "<div class = 'message'
          <p>Hey Saveethian! Complete them and try get out from this heaven!...</p>
         </div>";
}

else{
    echo "<div style = 'box-shadow: 0 0 20px 0 rgba(120, 120, 110,0.89);
                        padding: 1rem;
                        width: max-content;
                        background-color: #706e6e;'>
          <p>0 results found.</p>
          <p>Hey! Topper Keep it Up!...</p>
         </div></html>";
}

?>