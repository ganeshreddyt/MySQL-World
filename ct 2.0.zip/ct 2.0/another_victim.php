 
<?php

// file that includes all data base propeties for connection
include("database.php");

// logo
echo "<link rel='shortcut icon' href='logo.jpeg' type='image/x-icon'>";

// css file
echo "<link rel='stylesheet' type='text/css' href='query_results.css'/>";

session_start(); // get session variables

$victim1_id = $_SESSION['victim_id'];
$victim1_batch = $_SESSION['victim_batch'];

// get data from log in form...
$victim2_id = $_POST['victim2-identity'];
$victim2_pwd = $_POST['victim2-password'];

 
// query to fetch for valid another victim identification 
$query = "SELECT * FROM victims_data WHERE victim_id = '$victim2_id' AND victim_pwd = '$victim2_pwd'";

$response =  $conn->query($query); // get response from the query
$victim2_batch = $response->fetch_assoc()['victim_batch'];  // get victim batch

// check the response status
if($response->num_rows == 0){  // no such user exists
    echo "<script>
          alert('Beat the fellow!..No such saveethian exists!..Dey correct ahh sollu da!...');
          location.href = history.back();
          </script>";
}

else{
   // query for upcoming mandatory courses of two students
   $query = "SELECT v1.course_code as course_code,
                    v2.course_name as course_name,
                    v2.prerequisites as prerequisites
             FROM(SELECT t1.course_code as course_code,
                    t1.course_name as course_name
                  FROM (SELECT `Course Code` as course_code, `Course Name` as course_name
                  FROM `$victim1_batch` where `Course Type` = 'M') t1 LEFT JOIN
                    (SELECT course_code 
                     FROM victims_course_data
                     WHERE victim_id =  '$victim1_id' AND course_type = 'M') t2
                  ON t1.course_code = t2.course_code
                  WHERE t2.course_code IS NULL) v1 INNER JOIN
                  (SELECT t1.course_code as course_code,
                     t1.course_name as course_name, t1.prerequisites as prerequisites
                   FROM (SELECT `Course Code` as course_code, 
                                `Course Name` as course_name, 
                                `Prerequisites` as prerequisites
                         FROM `$victim2_batch` where `Course Type` = 'M') t1 LEFT JOIN
                        (SELECT course_code 
                         FROM victims_course_data
                         WHERE victim_id = '$victim2_id' AND course_type = 'M') t2
                   ON t1.course_code = t2.course_code
                   WHERE t2.course_code IS NULL) v2 
             ON v1.course_code = v2.course_code";

$result = $conn->query($query); //  execute the query


echo "<h2>Mandatory Courses That You Both Can Choose Are </h2>";
if($result->num_rows > 0){
   // printing each record in php file
   echo "<table> 
        <tr>
          <th>S.no </th>
          <th> CourseCode </th>
          <th> CourseName </th>
          <th> Prerequisite</th>
        </tr>";
   $s_no = 1;
   while($row = $result->fetch_assoc())
   {
       $row1 = $row['course_code'];
       $row2 = $row['course_name'];
       $row3 = $row['prerequisites'];
       echo"<tr>
            <td>" .$s_no. ".</td>".
            "<td>" .$row1. "</td>".
            "<td>" .$row2. "</td>".
            "<td>" .$row3. "</td>".
           "</tr>";
   
       $s_no++;
   }
   echo "</table>";
}
else{
   echo "<div style = 'box-shadow: 0 0 20px 0 rgba(120, 120, 110,0.89);
                       padding: 1rem;
                       width: max-content;
                       background-color: #706e6e;'>
           <p>0 results found.</p>
           <p>Hoo noooo...you can't choose any more together...</p>
         </div>";
}


// Queries For Electives..
 $query = "SELECT v1.course_code as course_code,
                  v2.course_name as course_name,
                  v2.prerequisites as prerequisites
           FROM(SELECT t1.course_code as course_code,
                  t1.course_name as course_name
                FROM (SELECT `Course Code` as course_code, `Course Name` as course_name
                FROM `$victim1_batch` where `Course Type` = 'E') t1 LEFT JOIN
                  (SELECT course_code 
                   FROM victims_course_data
                   WHERE victim_id =  '$victim1_id' AND course_type = 'E') t2
                ON t1.course_code = t2.course_code
                WHERE t2.course_code IS NULL) v1 INNER JOIN
                (SELECT t1.course_code as course_code,
                   t1.course_name as course_name, t1.prerequisites as prerequisites
                 FROM (SELECT `Course Code` as course_code, 
                              `Course Name` as course_name, 
                              `Prerequisites` as prerequisites
                       FROM `$victim2_batch` where `Course Type` = 'E') t1 LEFT JOIN
                      (SELECT course_code 
                       FROM victims_course_data
                       WHERE victim_id = '$victim2_id' AND course_type = 'E') t2
                 ON t1.course_code = t2.course_code
                 WHERE t2.course_code IS NULL) v2 
           ON v1.course_code = v2.course_code";

$result = $conn->query($query); // execute the query

echo "<h2>Elective Courses that you both can choose </h2>";
if($result->num_rows > 0){

// printing each record in php file
echo "<table> 
        <tr>
          <th>S.no </th>
          <th> CourseCode </th>
          <th> CourseName </th>
          <th> Prerequisite</th>
        </tr>";
$s_no = 1;
while($row = $result->fetch_assoc())
{
    $row1 = $row['course_code'];
    $row2 = $row['course_name'];
    $row3 = $row['prerequisites'];
    echo"<tr>
         <td>" .$s_no. ".</td>".
         "<td>" .$row1. "</td>".
         "<td>" .$row2. "</td>".
         "<td>" .$row3. "</td>".
        "</tr>";

    $s_no++;
}

echo "</table>";
}

else{
    echo "<div style = 'box-shadow: 0 0 20px 0 rgba(120, 120, 110,0.89);
                        padding: 1rem;
                        width: max-content;
                        background-color: #706e6e;'>
            <p>0 results found.</p>
            <p>Hoo noooo...you can't choose any more together...</p>
          </div>";
    }


// Queries for open elective 

$query = "SELECT v1.course_code as course_code,
                 v2.course_name as course_name,
                 v2.prerequisites as prerequisites
          FROM(SELECT t1.course_code as course_code,
                 t1.course_name as course_name
               FROM (SELECT `Course Code` as course_code, `Course Name` as course_name
               FROM `$victim1_batch` where `Course Type` = 'OE') t1 LEFT JOIN
                 (SELECT course_code 
                  FROM victims_course_data
                  WHERE victim_id =  '$victim1_id' AND course_type = 'OE') t2
               ON t1.course_code = t2.course_code
               WHERE t2.course_code IS NULL) v1 INNER JOIN
               (SELECT t1.course_code as course_code,
                  t1.course_name as course_name, t1.prerequisites as prerequisites
                FROM (SELECT `Course Code` as course_code, 
                             `Course Name` as course_name, 
                             `Prerequisites` as prerequisites
                      FROM `$victim2_batch` where `Course Type` = 'OE') t1 LEFT JOIN
                     (SELECT course_code 
                      FROM victims_course_data
                      WHERE victim_id = '$victim2_id' AND course_type = 'OE') t2
                ON t1.course_code = t2.course_code
                WHERE t2.course_code IS NULL) v2 
          ON v1.course_code = v2.course_code";

$result = $conn->query($query); // execute the query

echo "<h2>Open Elective Courses that you both can choose </h2>";
if($result->num_rows > 0){

// printing each record in php file
echo "<table> 
        <tr>
          <th>S.no </th>
          <th> CourseCode </th>
          <th> CourseName </th>
          <th> Prerequisite</th>
        </tr>";
$s_no = 1;
while($row = $result->fetch_assoc())
{
    $row1 = $row['course_code'];
    $row2 = $row['course_name'];
    $row3 = $row['prerequisites'];
    echo"<tr>
         <td>" .$s_no. ".</td>".
         "<td>" .$row1. "</td>".
         "<td>" .$row2. "</td>".
         "<td>" .$row3. "</td>".
        "</tr>";

    $s_no++;
}

echo "</table>";
}

else{
    echo "<div style = 'box-shadow: 0 0 20px 0 rgba(120, 120, 110,0.89);
                        padding: 1rem;
                        width: max-content;
                        background-color: #706e6e;'>
            <p>0 results found.</p>
            <p>Hoo noooo...you can't choose any more together...</p>
          </div></html>";
    }

}
   

?>


