<?php 

 // file that includes all data base propeties for connection
 include("database.php");

// to get session variables..
session_start();

// get session variables 
$victim_id = $_SESSION['victim_id'];

// query to get all basic details of the student
$query = "SELECT victim_id, victim_pwd, victim_regno, victim_gender 
          FROM victims_data
          WHERE victim_id = '$victim_id'";

$result = $conn->query($query); // process the query

// basically it won't happen bcz stu already logged in succesfully
if($result->num_rows == 0){
  echo "<script> 
        alert('Something going bad!..Pray for GOD and try again!...');
        location.href = project.html;
       </script>";
}

$obj = $result->fetch_assoc(); // to get all the requirements

$victim_regno = $obj['victim_regno'];
$victim_pwd = $obj['victim_pwd'];
$victim_gender = $obj['victim_gender'];

// print all basic information
echo "<html> <body> <table id = 'print-victim-details'> <th> <td></td> <td></td> </th>";
echo "<tr><td>Registration No </td><td>".$victim_regno."</td></tr>
      <tr><td>Identity  </td><td>".$victim_id."</td></tr>
      <tr><td>Password </td><td>".$victim_pwd."</td></tr>
      <tr><td>Gender </td><td>".$victim_gender."</td></tr></table></body></html>"; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="query_results.css">
    <title>Course Tracker</title>
</head>
<body>
    <div class="update-profile">
        <div class="note">
            <b><p>NOTE</p></b>
            <p>If you want update password alone enter your current id as it is.</p>
            <p>Else if you want update Id alone enter current password as it is.</p>
            <p>Otherwise you can change both of them.</p>
        </div>
        <div class="updated-data">
            <b><p>New Details</p></b>
            <form action="update_victim_data.php" method="post">
                <label for="victim_id">Enter new Identity</label>
                <input type="text" name="new-victim-id" placeholder="Enter new identity">
                <label for="victim_pwd">Enter new password</label>
                <input type="password" name="new-victim-pwd" placeholder="Enter new password">
                <label for="pwd-hint">Enter password hint</label>
                <input type="text" name="new-pwd-hint" id="pwd-hint">
                <input type="submit" value="UPDATE" id="btn">
            </form>
        </div>
    </div>
</body>
</html>
