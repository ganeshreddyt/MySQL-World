<?php

  // file that includes all data base propeties for connection
  include("database.php");

// // logo
// echo "<link rel='shortcut icon' href='logo.jpeg' type='image/x-icon'>";

// includes the external style..
echo "<link rel='stylesheet' type='text/css' href='query_results.css'/>"; 
 
session_start();  //starts session
 
$victim_id = $_SESSION["victim_id"];  
$victim_batch = $_SESSION["victim_batch"];

// Query completed mandatory courses
$query = "SELECT t1.course_code as course_code,
                 t2.course_name as course_name,
                 t2.prerequisites as prerequisites,
                 t1.course_grade as course_grade
          FROM (SELECT course_code, course_grade, course_type 
                FROM victims_course_data 
                WHERE victim_id = '$victim_id' and course_type = 'M') t1 JOIN 
                (SELECT `Course Code` as course_code,
                        `Course Name` as course_name,
                        `Prerequisites` as prerequisites
                 FROM `$victim_batch`) t2 on t1.course_code = t2.course_code
                 ORDER BY 1";


$result = $conn->query($query); // execute query

echo "<h2>Completed Mandatory Courses</h2>";
if($result->num_rows > 0){
    // printing each record in php file
    echo "<table> 
         <tr>
           <th>S_no </th>
           <th> Course_Code </th>
           <th> Course_Name </th>
           <th> Prerequisite</th>
           <th> Course_Grade</th>
         </tr>";
    $s_no = 1;
    while($row = $result->fetch_assoc())
    {
        $row1 = $row['course_code'];
        $row2 = $row['course_name'];
        $row3 = $row['prerequisites'];
        $row4 = $row['course_grade'];

    if($row4 == 'F'){
        echo "<tr style = 'color: red'>
        <td>" .$s_no. ".</td>".
        "<td>" .$row1. "</td>".
        "<td>" .$row2. "</td>".
        "<td>" .$row3. "</td>".
        "<td>" .$row4. "</td>".
      "</tr>";
    }
    else{
    echo"<tr>
        <td>" .$s_no. ".</td>".
        "<td>" .$row1. "</td>".
        "<td>" .$row2. "</td>".
        "<td>" .$row3. "</td>".
        "<td>" .$row4. "</td>".
        "</tr>";
    }
        $s_no++;
    }
    echo "</table>";
}
else{
    echo "<div style = 'box-shadow: 0 0 20px 0 rgba(120, 120, 110,0.89);
                        padding: 1rem;
                        width: max-content;
                        background-color: #706e6e;'>
          <p>0 results found.</p>
          <p>Hurry Up! Choose Mandatory from next semester.</p>
         </div>";
}

// Query completed electives and open electives courses
$query = "SELECT t1.course_code as course_code,
          t2.course_name as course_name,
          t2.prerequisites as prerequisites,
          t1.course_grade as course_grade
          FROM (SELECT course_code, course_grade, course_type 
          FROM victims_course_data 
          WHERE victim_id = '$victim_id' and course_type in ('E', 'OE')) t1 JOIN 
          (SELECT `Course Code` as course_code,
                 `Course Name` as course_name,
                 `Prerequisites` as prerequisites
          FROM `$victim_batch`) t2 on t1.course_code = t2.course_code
          ORDER BY 1";

$result = $conn->query($query); // it get all query results....
 
$remaining_electives = 8 - $result->num_rows;

if($remaining_electives > 0) // he needs few more
    echo "<h2>Completed Elective Courses <br> you need '$remaining_electives' more..</h2>";
else if($remaining_electives == 0)
    echo "<h2>Completed Elective Courses <br> Hey!..you completed all Electives...</h2>";
else
    echo "<h2>Completed Elective Courses <br> Hey!..you did more than required i.e., 8 <br> it will results in wrong CGPA. <br> delete and upload again.</h2>";

if($result->num_rows > 0){
    // printing each record in php file
    echo "<table> 
         <tr>
           <th>S_no </th>
           <th> Course_Code </th>
           <th> Course_Name </th>
           <th> Prerequisite</th>
           <th> Course_Grade</th>
         </tr>";
    $s_no = 1;
    while($row = $result->fetch_assoc())
    {
        $row1 = $row['course_code'];
        $row2 = $row['course_name'];
        $row3 = $row['prerequisites'];
        $row4 = $row['course_grade'];

    if($row4 == 'F'){
        echo "<tr style = 'color: red'>
        <td>" .$s_no. ".</td>".
        "<td>" .$row1. "</td>".
        "<td>" .$row2. "</td>".
        "<td>" .$row3. "</td>".
        "<td>" .$row4. "</td>".
      "</tr>";
    }
    else{
    echo"<tr>
        <td>" .$s_no. ".</td>".
        "<td>" .$row1. "</td>".
        "<td>" .$row2. "</td>".
        "<td>" .$row3. "</td>".
        "<td>" .$row4. "</td>".
        "</tr>";
    }
        $s_no++;
    }
    echo "</table>";
}

else{
    echo "<div style = 'box-shadow: 0 0 20px 0 rgba(120, 120, 110,0.89);
                        padding: 1rem;
                        width: max-content;
                        background-color: #706e6e;'>
          <p>0 results found.</p>
          <p>Hurry Up! Choose Electives from next semester.</p>
          </div>";
} 

?>
 